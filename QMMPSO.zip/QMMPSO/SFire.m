function flag = SFire(point, time, V_Fire, ellipse_params)

    flag = 0;
    x = point(1);
    y = point(2);
    
    for i = 1:size(ellipse_params, 1)
        center_x = ellipse_params(i, 1);
        center_y = ellipse_params(i, 2);
        a = ellipse_params(i, 4);
        b = ellipse_params(i, 5);
        
        % Calculate the semi-axis of the ellipse that varies with time
        a = a + time/60 * V_Fire;
        b = b + time/60 * V_Fire;
        
       
        expansion_radius_km = V_Fire * (10 / 60); 
        expanded_a = a + expansion_radius_km;
        expanded_b = b + expansion_radius_km;
        
        % Determine whether the point is within the initial or diffused ellipse
        if ((x - center_x)^2) / (a^2) + ((y - center_y)^2) / (b^2) <= 1
            flag = 2;
            return;
        elseif ((x - center_x)^2) / (expanded_a^2) + ((y - center_y)^2) / (expanded_b^2) <= 1
            flag = 1;
            return;
        end
    end
end

