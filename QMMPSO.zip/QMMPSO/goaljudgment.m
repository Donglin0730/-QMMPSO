function [nsaftime, ngoalPos] = goaljudgment(startPos,goalPos,V_Uav,V_Fire,ellipse_params)
    %% Calculate the safe time
    t_max = 200;
    dt = 0.01;
    saftime = zeros(1, 5);
    DSP = zeros(1, 5);
    P1 = startPos(1,1:3);
    for i = 1:size(goalPos, 1)
        P2 = goalPos(i,1:3);
        time = 0; % min
        while time <= t_max            
            % flag = SFire(P2, time, V_Fire, ellipse_params);
            % if flag ~= 0
            %     % fprintf('点%d在%.2f分时被警戒区覆盖。\n',i , time);
            %     break; 
            % end

            time = time + dt;
        end
        saftime(i) = time;
        DSP(i) = sqrt(sum((P2 - P1).^2));
    end
    %% Sort by safety time and task time
    goaltime = goalPos(:,4).';  % Obtain task time
    score = goaltime/sum(goaltime)*0.1+saftime/sum(saftime)*0.8+DSP/sum(DSP)*0.1;  % The sorting score is calculated based on the task time and safety time

    [~, sortIdx] = sort(score, 'ascend');
    for i = 1:size(goalPos,1)
        ngoalPos(i,:) = goalPos(sortIdx(i),:);
    end
    for i = 1:size(goalPos,1)
        nsaftime(i) = saftime(sortIdx(i));
    end    
    %% Calculate and verify whether the route can be successful
    temp = 0;
    tfly = zeros(1, 5);
    tget = zeros(1, 5);
    tfinish = zeros(1, 5);
    intersect = zeros(1, 3);
    for i = 1:size(ngoalPos,1)
        P2 = ngoalPos(i,1:3);
        for j = 1:size(ellipse_params, 1)
            center = ellipse_params(j,1:2);
            a = ellipse_params(j, 4)+V_Fire*(nsaftime(i)-ngoalPos(i,4))/60+V_Fire/6;
            b = ellipse_params(j, 5)+V_Fire*(nsaftime(i)-ngoalPos(i,4))/60+V_Fire/6;
            intersect(j) = lineEllipseIntersect(P1, P2, center, a, b);         
        end
        distance = sqrt(sum((P2 - P1).^2));
        for j = [1,2,3]
            if j * intersect(j)
                a = ellipse_params(j, 4)+V_Fire*(nsaftime(i)-ngoalPos(i,4))/60+V_Fire/6;
                b = ellipse_params(j, 5)+V_Fire*(nsaftime(i)-ngoalPos(i,4))/60+V_Fire/6;
                distance = distance + pi * (3 * (a + b) - sqrt((3*a + b) * (a + 3*b)))/2;
            end
        end
        tfly(i) = distance/V_Uav/60; 
        tget(i) = temp + tfly(i);
        if (tget(i) + ngoalPos(i, 4)) < nsaftime(i)
            tfinish(i) = tget(i) + ngoalPos(i, 4);
            temp = tfinish(i);
        else 
            fprintf("建议采用多无人机方案！！！");
            break
        end
        P1 = P2;
    end
    
    
    % Determine whether the flight path projection intersects with the fire projection
    function intersect = lineEllipseIntersect(P1, P2, center, a, b)
        A = (P2(1) - P1(1))^2 / a^2 + (P2(2) - P1(2))^2 / b^2;
        B = 2 * ((P2(1) - P1(1)) * (P1(1) - center(1)) / a^2 + ...
                 (P2(2) - P1(2)) * (P1(2) - center(2)) / b^2);
        C = (P1(1) - center(1))^2 / a^2 + (P1(2) - center(2))^2 / b^2 - 1;
    
        % Solve the quadratic equation for t
        t = roots([A, B, C]);
    
        % Check if there are real solutions in the interval [0, 1]
        intersect = any(imag(t) == 0 & t >= 0 & t <= 1);
    end
end 