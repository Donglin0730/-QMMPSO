function  [fitness, bestflag, pflag, bestnum, pbestX_seq, pbestY_seq, pbestZ_seq, particles_updated_in_calfitness] = calfitness(pmax,pmin,startPos,goalPos,ellipse_params,M,N,ngoalPos,X,Y,Z,V_Uav,V_Fire,nsaftime,goodmark, original_particles_for_this_call)
    %% Parameter setting
    persistent q_agent;
    if isempty(q_agent)
        q_agent = QLearning_Agent(0.5);
    end

    particles_updated_in_calfitness = original_particles_for_this_call; % 将被修改

    Pos = [startPos; ngoalPos(:,(1:3))];
    num_tasks = size(goalPos,1);
    points_per_segment_genes = M / num_tasks;
    head_pos_full = Pos(1,:);

    %% Fitness calculation
    fitness = zeros(N,1);
    nfitness_internal = 1000000; %
    pflag = zeros(N,num_tasks);
    
    pbestX_seq_candidate = [];
    pbestY_seq_candidate = [];
    pbestZ_seq_candidate = [];
    bestnum_candidate = 1;
    bestflag_candidate = zeros(1,num_tasks);

    q_learning_rate_for_control_points = 0.05;

    for n = 1:N 
        current_particle_genes_for_eval = particles_updated_in_calfitness(n,:); 

        % Generate path
        particle_anchor_points_n = head_pos_full;
        for i_task = 1:num_tasks
            start_gene_idx = (i_task-1) * 3 * points_per_segment_genes + 1;
            end_gene_idx   = i_task * 3 * points_per_segment_genes;
            mid_genes = current_particle_genes_for_eval(start_gene_idx : end_gene_idx);
            mid_control_points = reshape(mid_genes, 3, points_per_segment_genes)';
            particle_anchor_points_n = [particle_anchor_points_n; mid_control_points];
            particle_anchor_points_n = [particle_anchor_points_n; Pos(i_task+1,:)];
        end
        
        x_anchors = particle_anchor_points_n(:, 1);
        y_anchors = particle_anchor_points_n(:, 2);
        z_anchors = particle_anchor_points_n(:, 3);
        
        i_seq = linspace(0,1,length(x_anchors));
        I_seq = linspace(0,1,100);
        X_seq_orig = spline(i_seq,x_anchors,I_seq); 
        Y_seq_orig = spline(i_seq,y_anchors,I_seq);
        Z_seq_orig = spline(i_seq,z_anchors,I_seq);
        path_orig = [X_seq_orig', Y_seq_orig', Z_seq_orig'];
    
        %% Path cost
        dx = diff(X_seq_orig);
        dy = diff(Y_seq_orig);
        dz = diff(Z_seq_orig);
        total_h=sum(Z_seq_orig)/100;
        C1 = sum(sqrt(dx.^2 + dy.^2 + dz.^2)) + total_h;
        current_fitness_val = C1;

        %% Corner kick penalty 
        penalty_threshold = deg2rad(45); 
        penalty_weight = 10; 
        penalty_turn = 0;
        directions = diff(path_orig, 1, 1); 
        if size(directions,1) >= 2
            directions = directions ./ vecnorm(directions, 2, 2);
            for i_turn = 1:size(directions,1)-1 % 修改循环条件
                v1 = directions(i_turn, :);
                v2 = directions(i_turn+1, :);
                cos_theta = dot(v1, v2); 
                cos_theta = max(min(cos_theta, 1), -1); 
                theta = acos(cos_theta); 
                if theta > penalty_threshold
                    penalty_turn = penalty_turn + penalty_weight * (theta - penalty_threshold)^2;
                end
            end
        end
        current_fitness_val = current_fitness_val + penalty_turn;
        
        %% Detection of fire intrusion and ground collision along the route
        ttask = 0;
        p_eval = round(linspace(1,100,num_tasks+1));
        flag_particle_segment = zeros(1,num_tasks);

        temp_path_for_q_correction = path_orig; 

        for a = 1:num_tasks
            path_segment_indices = p_eval(a) : p_eval(a+1);
            if p_eval(a) == p_eval(a+1) && p_eval(a) == 100 
                if p_eval(a) > 1; path_segment_indices = [p_eval(a)-1, p_eval(a)]; end
            end
            if isempty(path_segment_indices); continue; end

            dx_seg = diff(X_seq_orig(path_segment_indices));
            dy_seg = diff(Y_seq_orig(path_segment_indices));
            dz_seg = diff(Z_seq_orig(path_segment_indices));
            ds_seg = sum(sqrt(dx_seg.^2 + dy_seg.^2 + dz_seg.^2));
            tget = ttask + ds_seg / V_Uav / 60;
            
            if tget > nsaftime(a) - ngoalPos(a,4)
                flag_particle_segment(a) = 3;
                current_fitness_val = current_fitness_val + 100; 
            end 
            ttask = ttask + ngoalPos(a,4);

            bpath_segment_eval = temp_path_for_q_correction(path_segment_indices,:); 

            for k_point = 1:size(bpath_segment_eval,1)
                checkp = bpath_segment_eval(k_point,:); 
                x_cp = checkp(1,1); y_cp = checkp(1,2); z_cp = checkp(1,3);

                z_interp_terrain = interp2(X,Y,Z,x_cp,y_cp,'linear', -1);
                if z_interp_terrain == -1 
                    flag_particle_segment(a) = 5; 
                    current_fitness_val = current_fitness_val + 10000;
                    z_interp_terrain = 0; 
                end


                if z_cp > 0.2 && flag_particle_segment(a) == 0
                    flag_particle_segment(a) = 4; current_fitness_val = current_fitness_val + 100; 
                end
                if z_interp_terrain*1.1 > z_cp && flag_particle_segment(a) == 0
                    flag_particle_segment(a) = 3; current_fitness_val = current_fitness_val + 1000;
                end
                
                time_at_checkp = ttask - ngoalPos(a,4) + (k_point/size(bpath_segment_eval,1)) * (ds_seg / V_Uav / 60);
                bflag_fire = SFire(checkp, time_at_checkp, V_Fire, ellipse_params);

                if bflag_fire == 2 && flag_particle_segment(a) == 0
                    flag_particle_segment(a) = 2; current_fitness_val = current_fitness_val + 100; 
                elseif bflag_fire == 1 && flag_particle_segment(a) == 0
                    if z_cp < z_interp_terrain+0.02
                        flag_particle_segment(a) = 2; current_fitness_val = current_fitness_val + 100; 
                    end
                end
                
                
                if goodmark == 0
                    fire_info.X = X; fire_info.Y = Y; fire_info.Z = Z;
                    fire_info.ellipse_params = ellipse_params;
                    
                    original_checkp_for_q = checkp;
                    [corrected_point_q, q_agent] = q_agent.correct_path(original_checkp_for_q, fire_info);
                    
                    correction_vector = corrected_point_q - original_checkp_for_q;

                    % Identify and modify the control point genes
                    start_gene_idx_for_segment_a = (a-1) * 3 * points_per_segment_genes + 1;
                    end_gene_idx_for_segment_a   = a * 3 * points_per_segment_genes;
                    
                    num_control_points_in_segment_genes = points_per_segment_genes;
                    if num_control_points_in_segment_genes > 0
                        genes_to_modify = current_particle_genes_for_eval(start_gene_idx_for_segment_a : end_gene_idx_for_segment_a);
                        reshaped_genes = reshape(genes_to_modify, 3, num_control_points_in_segment_genes)';
                        
                        for cp_idx = 1:num_control_points_in_segment_genes
                            reshaped_genes(cp_idx, :) = reshaped_genes(cp_idx, :) + (correction_vector / num_control_points_in_segment_genes) * q_learning_rate_for_control_points;
                        end
                        
                        
                        pmax_segment = reshape(pmax(1, start_gene_idx_for_segment_a : end_gene_idx_for_segment_a), 3, num_control_points_in_segment_genes)';
                        pmin_segment = reshape(pmin(1, start_gene_idx_for_segment_a : end_gene_idx_for_segment_a), 3, num_control_points_in_segment_genes)';
                        reshaped_genes = max(min(reshaped_genes, pmax_segment), pmin_segment);


                        modified_genes_flat = reshape(reshaped_genes', 1, []);
                        current_particle_genes_for_eval(start_gene_idx_for_segment_a : end_gene_idx_for_segment_a) = modified_genes_flat;
                        
                        
                        particles_updated_in_calfitness(n,:) = current_particle_genes_for_eval;

                    end
                end 
            end 
        end 

        fitness(n) = current_fitness_val;
        pflag(n,:) = flag_particle_segment;

        if fitness(n) < nfitness_internal
            nfitness_internal = fitness(n);
            bestnum_candidate = n;
            bestflag_candidate = flag_particle_segment;
            
            pbestX_seq_candidate = X_seq_orig;
            pbestY_seq_candidate = Y_seq_orig;
            pbestZ_seq_candidate = Z_seq_orig;
        end
    end 

    bestnum = bestnum_candidate;
    bestflag = bestflag_candidate;
    pbestX_seq = pbestX_seq_candidate;
    pbestY_seq = pbestY_seq_candidate;
    pbestZ_seq = pbestZ_seq_candidate;
    

end