function drawfire(time, V_Fire, ellipse_params)
   
   % Plot initial and expanded elliptic cylinders
    hold on;
    view(3); % 3D view
    
    for i = 1:size(ellipse_params, 1)
        % Initial ellipse parameters
        x0 = ellipse_params(i, 1);
        y0 = ellipse_params(i, 2);
        z0 = ellipse_params(i, 3);
        a = ellipse_params(i, 4)+V_Fire*time/60;
        b = ellipse_params(i, 5)+V_Fire*time/60;
        h = ellipse_params(i, 6);
        
        % Draw the initial elliptic cylinder
        drawEllipseCylinder(x0, y0, z0, a, b, h, 'b');
        
        % Calculate the expansion after 10 minutes
        a_expanded = a + V_Fire/6;
        b_expanded = b + V_Fire/6;
        h_expanded = h - 0.1; % 100 meters less in height
        
        % Draw the expanded elliptic cylinder
        drawEllipseCylinder(x0, y0, z0, a_expanded, b_expanded, h_expanded, 'r');
    end
    
    xlabel('X Axis (km)');
    ylabel('Y Axis (km)');
    zlabel('Z Axis (km)');
    title(['Elliptic Cylinders at Time: ', num2str(time), ' min']);
    hold off;
end

function drawEllipseCylinder(x0, y0, z0, a, b, h, color)
    % Number of points for smooth ellipse
    n = 200;
    theta = linspace(0, 2*pi, n);
    
    % Ellipse points in the xy-plane
    x = x0 + a * cos(theta);
    y = y0 + b * sin(theta);
    
    % Draw the bottom ellipse (at z0)
    fill3(x, y, z0*ones(size(x)), color); % Filling the bottom ellipse with color
    hold on; % Keep the current plot and add the new plots
    
    % Draw the top ellipse (at z0 + h)
    fill3(x, y, (z0+h)*ones(size(x)), color); % Filling the top ellipse with color
    
    % Connect the edges to form the sides of the cylinder
    for i = 1:n
        plot3([x(i) x(i)], [y(i) y(i)], [z0 z0+h], 'Color', color);
    end

end