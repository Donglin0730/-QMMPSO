clc
clear
close all

%% MAP
startPos = [];%Set it according to your own data

goalPos = [];%Set it according to your own data

Traction_points = [];%Set it according to your own data
[X,Y,Z] = drawmap(startPos, goalPos); 
hold on;
%% FIRE
O = 0.3;
M = 1.5;
P = 3;
V_Fire = (O + P + 4 * M) / 6;
V_Uav = 0.05;
ellipse_params = [
    2.5, 4, 0, 1.1, 0.7, 0.2; 
    6, 2, 0, 1.2, 0.8, 0.2;  
    8.5, 5, 0, 0.7, 1.2, 0.2
];

time = 0;
drawfire(time, V_Fire, ellipse_params);
hold on;
xlabel('X Axis (km)');
ylabel('Y Axis (km)');
zlabel('Z Axis (km)');
title('Map with Fire Elliptic Cylinders');

iterations_per_run = 100;
run_idx = 1;
[bestx_run, besty_run, bestz_run, gbest_run_control_points, gbest_fit_run] = ...
        QMMPSO(Traction_points,startPos,goalPos,ellipse_params,V_Fire, V_Uav, X, Y, Z, iterations_per_run); % 传递完整路径

hold on;
gbestx = gbest(1:3:end); 

gbesty = gbest(2:3:end); 
gbestz = gbest(3:3:end); 
scatter3(gbestx, gbesty, gbestz, 'filled');
plot3(bestx, besty, bestz, '-b');
fid = fopen('path.txt', 'w');
fprintf(fid, '%f,',gbest);
fprintf(fid, '\n');
fprintf(fid, '%f,',bestx);
fprintf(fid, '\n');
fprintf(fid, '%f,',besty);
fprintf(fid, '\n');
fprintf(fid, '%f,',bestz);
fclose(fid);
xlabel('X');
ylabel('Y');
zlabel('Z');
grid on;
hold off;
