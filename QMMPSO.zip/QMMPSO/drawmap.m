function [X, Y, Z] = drawmap(startPos, goalPos)  

    load('dataMatrix2.mat'); % It needs to be modified to your own elevation data

    x = dataMatrix2(:, 1);  
    y = dataMatrix2(:, 2);  
    z = dataMatrix2(:, 3);  
    xmax=max(x);
    xmin=min(x);
    ymax=max(y);
    ymin=min(y);
    [X,Y]=meshgrid(xmin:0.1:xmax,ymin:0.1:ymax);

    Z=griddata(x,y,z,X,Y,'cubic'); 
   
    %% fig
    figure(1); 
    hold on;
    
    for i = 1:size(goalPos, 1)
        x = goalPos(i, 1);
        y = goalPos(i, 2);
        z = goalPos(i, 3);
        scatter3(x, y, z, 50, "yellow", 'filled');
    end
    
    sx = startPos(1);
    sy = startPos(2);
    sz = startPos(3);
    scatter3(sx, sy, sz, 50, "red", 'filled');
    
    

    meshc(X, Y, Z);  
    shading flat;  
    title('Interpolated Surface');  
    xlabel('X');  
    ylim([0,9]);
    ylabel('Y');  
    zlim([0,0.3]);
    zlabel('Z');  
    hold on;
   
end