classdef QLearning_Agent
    properties
        QTable
        state_grid
        action_space
        alpha         % Learning rate
        gamma = 0.9   % Discount factor
        epsilon       % Exploration rate
         
        % Decay parameters
        initial_alpha
        min_alpha
        alpha_decay_rate
        initial_epsilon
        min_epsilon
        epsilon_decay_rate
        
        total_updates = 0 % Counter for Q-value updates
    end
    
    methods
        function obj = QLearning_Agent(grid_res, learning_params)
            %% State Space Definition (Discretized Position)
            % X, Y use grid_res; Z uses finer resolution
            x_edges = 0:grid_res:10; 
            y_edges = 0:grid_res:8;
            z_edges = 0.05:0.025:0.2; % Finer resolution for altitude
            [X_grid, Y_grid, Z_grid] = meshgrid(x_edges, y_edges, z_edges);
            obj.state_grid = [X_grid(:) Y_grid(:) Z_grid(:)];
            
            %% Action Space Definition (3D Movement)
            obj.action_space = [ 
                 0.1  0.0  0.0;   % Move X+
                -0.1  0.0  0.0;   % Move X-
                 0.0  0.1  0.0;   % Move Y+
                 0.0 -0.1  0.0;   % Move Y-
                 0.0  0.0  0.015; % Move Z+ (Climb)
                 0.0  0.0 -0.015; % Move Z- (Descend)
                 0.0  0.0  0.0];  % No Action / Hold
            
            % Initialize Q-Table
            obj.QTable = zeros(size(obj.state_grid, 1), size(obj.action_space, 1));

            % Initialize Learning Parameters
            if nargin < 2 
                % Default parameters if not provided
                learning_params.initial_alpha = 0.5; 
                learning_params.min_alpha = 0.01;
                learning_params.alpha_decay_rate = 0.999; 
                
                learning_params.initial_epsilon = 0.8; 
                learning_params.min_epsilon = 0.05;
                learning_params.epsilon_decay_rate = 0.999; 
            end
            
            obj.initial_alpha = learning_params.initial_alpha;
            obj.min_alpha = learning_params.min_alpha;
            obj.alpha_decay_rate = learning_params.alpha_decay_rate;
            obj.alpha = obj.initial_alpha;

            obj.initial_epsilon = learning_params.initial_epsilon;
            obj.min_epsilon = learning_params.min_epsilon;
            obj.epsilon_decay_rate = learning_params.epsilon_decay_rate;
            obj.epsilon = obj.initial_epsilon;
        end
        
        function [corrected_point, reward_value, obj] = correct_path(obj, current_point, fire_info, terrain_limits)
            % Default terrain limits if not provided
            if nargin < 4
                terrain_limits.min_x = 0; terrain_limits.max_x = 10;
                terrain_limits.min_y = 0; terrain_limits.max_y = 8;
                terrain_limits.min_z = 0.05; terrain_limits.max_z = 0.2;
            end

            %% State Encoding
            % Find the nearest discretized state index
            distances_to_state_points = sum((obj.state_grid - current_point).^2, 2); 
            [~, state_idx] = min(distances_to_state_points);
            
            %% Action Selection (Epsilon-Greedy)
            if rand < obj.epsilon
                action_idx = randi(size(obj.action_space, 1)); % Explore: Random action
            else
                [~, action_idx] = max(obj.QTable(state_idx, :)); % Exploit: Best known action
                
                % Tie-breaking: Randomly select among max Q-values
                max_q_indices = find(obj.QTable(state_idx, :) == max(obj.QTable(state_idx, :)));
                if ~isempty(max_q_indices)
                    action_idx = max_q_indices(randi(length(max_q_indices)));
                end
            end
            
            %% Execute Action
            potential_next_point = current_point + obj.action_space(action_idx, :);
            
            % Boundary Clamping
            corrected_point = potential_next_point;
            corrected_point(1) = max(terrain_limits.min_x, min(corrected_point(1), terrain_limits.max_x));
            corrected_point(2) = max(terrain_limits.min_y, min(corrected_point(2), terrain_limits.max_y));
            corrected_point(3) = max(terrain_limits.min_z, min(corrected_point(3), terrain_limits.max_z));
            
            %% Reward Calculation
            reward = obj.compute_reward_v2(current_point, corrected_point, fire_info, terrain_limits);
            reward_value = reward; 

            %% Q-Value Update
            % Identify next state
            distances_to_next_state_points = sum((obj.state_grid - corrected_point).^2, 2);
            [~, next_state_idx] = min(distances_to_next_state_points);
            
            % Bellman Equation
            current_q_value = obj.QTable(state_idx, action_idx);
            max_next_q_value = max(obj.QTable(next_state_idx, :));
            if isempty(max_next_q_value) 
                max_next_q_value = 0;
            end
            
            new_q_value = current_q_value + obj.alpha * (reward + obj.gamma * max_next_q_value - current_q_value);
            obj.QTable(state_idx, action_idx) = new_q_value;
            
            %% Parameter Decay
            obj.total_updates = obj.total_updates + 1;
            obj = obj.decay_parameters();
        end

        function obj = decay_parameters(obj)
            % Linear multiplication decay
            obj.alpha = obj.alpha * obj.alpha_decay_rate;
            obj.epsilon = obj.epsilon * obj.epsilon_decay_rate;

            % Ensure values do not drop below minimum thresholds
            obj.alpha = max(obj.min_alpha, obj.alpha);
            obj.epsilon = max(obj.min_epsilon, obj.epsilon);
        end

        function reward = compute_reward_v2(obj, old_point, new_point, fire_info, terrain_limits)
            reward = 0; 
            
            %% 1. Terrain Collision Penalty
            terrain_z_at_new_point = interp2(fire_info.X, fire_info.Y, fire_info.Z, new_point(1), new_point(2), 'linear', -Inf);
            
            penalty_terrain_collision = -200; 
            penalty_too_low = -50;          
            safety_factor_terrain = 1.1;    
            min_abs_altitude_above_terrain = 0.01; 

            if terrain_z_at_new_point == -Inf % Out of map bounds
                reward = reward + penalty_terrain_collision;
            elseif new_point(3) < terrain_z_at_new_point + min_abs_altitude_above_terrain % Below absolute minimum clearance
                 reward = reward + penalty_terrain_collision;
            elseif new_point(3) < terrain_z_at_new_point * safety_factor_terrain % Below safety margin
                reward = reward + penalty_too_low;
            end

            %% 2. Fire Avoidance Reward/Penalty
            penalty_in_fire_core = -50;
            penalty_in_fire_buffer = -10; 
            reward_moving_away_from_fire = 1000; 
            fire_buffer_dist = 0.1; % km

            for i = 1:size(fire_info.ellipse_params, 1)
                cx = fire_info.ellipse_params(i, 1);
                cy = fire_info.ellipse_params(i, 2);
                ea = fire_info.ellipse_params(i, 4); 
                eb = fire_info.ellipse_params(i, 5); 

                % Normalized distance squared (Core and Buffer)
                norm_dist_sq_core_old = ((old_point(1)-cx)/ea)^2 + ((old_point(2)-cy)/eb)^2;
                norm_dist_sq_core_new = ((new_point(1)-cx)/ea)^2 + ((new_point(2)-cy)/eb)^2;
                
                norm_dist_sq_buffer_old = ((old_point(1)-cx)/(ea + fire_buffer_dist))^2 + ((old_point(2)-cy)/(eb + fire_buffer_dist))^2;
                norm_dist_sq_buffer_new = ((new_point(1)-cx)/(ea + fire_buffer_dist))^2 + ((new_point(2)-cy)/(eb + fire_buffer_dist))^2;

                % Penalty for Entering Threat Zones
                if norm_dist_sq_core_new <= 1
                    reward = reward + penalty_in_fire_core;
                elseif norm_dist_sq_buffer_new <= 1 
                    reward = reward + penalty_in_fire_buffer;
                end
                
                % Reward for Moving Away (Trend-based)
                if norm_dist_sq_core_old > norm_dist_sq_core_new % Moving closer (Bad trend)
                    reward = reward - 20; 
                elseif norm_dist_sq_core_new > norm_dist_sq_core_old % Moving away (Good trend)
                    % Only reward if strictly necessary (i.e., was previously in danger)
                    if norm_dist_sq_buffer_old <= 1 
                        reward = reward + reward_moving_away_from_fire * (sqrt(norm_dist_sq_core_new) - sqrt(norm_dist_sq_core_old));
                    end
                end
            end

            %% 3. Altitude Limit Penalty
            if new_point(3) > terrain_limits.max_z % Too high (Smoke layer)
                reward = reward - 20; 
            elseif new_point(3) < terrain_limits.min_z % Too low (Mission limit)
                reward = reward - 20;
            end
          
        end
    end
end