function [fitness, bestflag, pflag, bestnum, pbestX_seq, pbestY_seq, pbestZ_seq, particles_updated] = calfitness(iter, pmax_passed, pmin_passed, startPos, goalPos, ellipse_params, M, N, particles, ngoalPos, X, Y, Z, V_Uav, V_Fire, nsaftime, goodmark, q_agent_global)
    %% Parameter Setup
    q_agent = q_agent_global;
    particles_updated = particles; % Initialize output matrix
    q_learning_rate_for_control_points = 0.05; % Learning rate for gene feedback
 
    %% Particle Decoding and Integration
    % Combine particle genes (control points) with fixed start/goal anchors to form complete path skeletons
    one = ones(N, 1);
    Pos = [startPos; ngoalPos(:, (1:3))];
    head_anchor_points = one * Pos(1, :); % Start point for all particles

    num_tasks = size(goalPos, 1);
    points_per_segment_genes = M / num_tasks;
    temp_particles_segments = [];

    for i_task = 1:num_tasks
        start_idx_genes = (i_task-1) * 3 * points_per_segment_genes + 1;
        end_idx_genes = i_task * 3 * points_per_segment_genes;
        
        mid_genes_current_segment = particles(:, start_idx_genes:end_idx_genes);
        segment_end_anchor_point = one * Pos(i_task+1, :); % Task destination point
        
        current_segment_anchors = [mid_genes_current_segment, segment_end_anchor_point];
        temp_particles_segments = [temp_particles_segments, current_segment_anchors]; %#ok<AGROW>
    end
    particles_z_for_pathgen = [head_anchor_points, temp_particles_segments];

    %% Initialize Cost Storage
    % Costs are stored separately first to apply the Adaptive Weighting Strategy later
    raw_cost_length = zeros(N, 1); % Path length
    raw_cost_height = zeros(N, 1); % Average altitude (unweighted)
    raw_cost_turn   = zeros(N, 1); % Turning angle penalty (unweighted)
    raw_cost_hard   = zeros(N, 1); % Hard constraints (Collision, Time, Fire)

    pflag = zeros(N, num_tasks); % Constraint violation flags per segment

    %% Loop through Particles
    for n = 1:N
        % Flatten and reshape anchors for the n-th particle
        particle_anchors_n_flat = particles_z_for_pathgen(n, :);
        particle_anchors_n_matrix = reshape(particle_anchors_n_flat, 3, (size(particles_z_for_pathgen, 2)) / 3)';

        x_anchors = particle_anchors_n_matrix(:, 1);
        y_anchors = particle_anchors_n_matrix(:, 2);
        z_anchors = particle_anchors_n_matrix(:, 3);

        % Cubic Spline Interpolation to generate smooth trajectory
        i_seq_anchors = linspace(0, 1, length(x_anchors));
        I_seq_path = linspace(0, 1, 100);                 
        X_seq = spline(i_seq_anchors, x_anchors, I_seq_path);
        Y_seq = spline(i_seq_anchors, y_anchors, I_seq_path);
        Z_seq = spline(i_seq_anchors, z_anchors, I_seq_path);
        path = [X_seq', Y_seq', Z_seq'];

        %% C1: Path Length & Height Cost
        dx = diff(X_seq);
        dy = diff(Y_seq);
        dz = diff(Z_seq);

        % Calculate pure path length
        raw_cost_length(n) = sum(sqrt(dx.^2 + dy.^2 + dz.^2));

        % Calculate average flight altitude
        raw_cost_height(n) = sum(Z_seq) / length(Z_seq);

        %% C2: Turn Angle Cost
        num_points_path = size(path, 1);
        penalty_threshold_turn = deg2rad(45); % Max allowable turn angle
        temp_turn_penalty = 0;

        if num_points_path >= 3
            directions = diff(path, 1, 1);
            directions_norm = vecnorm(directions, 2, 2);

            valid_dirs_idx = directions_norm > 1e-9;
            normalized_directions = zeros(size(directions));
            normalized_directions(valid_dirs_idx, :) = directions(valid_dirs_idx, :) ./ directions_norm(valid_dirs_idx);

            for i_turn = 1:size(normalized_directions, 1)-1
                if ~valid_dirs_idx(i_turn) || ~valid_dirs_idx(i_turn+1)
                    continue;
                end
                v1 = normalized_directions(i_turn, :);
                v2 = normalized_directions(i_turn+1, :);
                cos_theta = dot(v1, v2);
                cos_theta = max(min(cos_theta, 1), -1);
                theta = acos(cos_theta);

                if theta > penalty_threshold_turn
                    % Accumulate squared penalty for excessive turning
                    temp_turn_penalty = temp_turn_penalty + (theta - penalty_threshold_turn)^2;
                end
            end
        end
        raw_cost_turn(n) = temp_turn_penalty;

        %% Hard Constraints (Time, Terrain, Fire)
        current_hard_penalty = 0;
        ttask_total_time_at_prev_goal = 0;
        p_eval_indices = round(linspace(1, num_points_path, num_tasks+1));
        flag_particle_segment = zeros(1, num_tasks);

        for a = 1:num_tasks
            % Define path segment indices
            segment_start_idx_in_path = p_eval_indices(a);
            segment_end_idx_in_path = p_eval_indices(a+1);

            if segment_start_idx_in_path == segment_end_idx_in_path && segment_start_idx_in_path == num_points_path
                if segment_start_idx_in_path > 1
                    path_segment_indices_in_X_seq = [segment_start_idx_in_path-1, segment_start_idx_in_path];
                else
                    path_segment_indices_in_X_seq = [segment_start_idx_in_path, segment_start_idx_in_path];
                end
            else
                 path_segment_indices_in_X_seq = segment_start_idx_in_path:segment_end_idx_in_path;
            end

            if isempty(path_segment_indices_in_X_seq) || length(path_segment_indices_in_X_seq) < 2
                 ds_seg = 0;
            else
                dx_seg = diff(X_seq(path_segment_indices_in_X_seq));
                dy_seg = diff(Y_seq(path_segment_indices_in_X_seq));
                dz_seg = diff(Z_seq(path_segment_indices_in_X_seq));
                ds_seg = sum(sqrt(dx_seg.^2 + dy_seg.^2 + dz_seg.^2));
            end

            % Calculate Time
            time_to_fly_current_segment = ds_seg / V_Uav / 60;
            tget_segment_end = ttask_total_time_at_prev_goal + time_to_fly_current_segment;

            % Constraint: Mission Timeout
            if tget_segment_end > (nsaftime(a) - ngoalPos(a, 4))
                flag_particle_segment(a) = 3;
                current_hard_penalty = current_hard_penalty + 100;
            end

            ttask_total_time_at_prev_goal = tget_segment_end + ngoalPos(a, 4);
            bpath_segment_eval = path(path_segment_indices_in_X_seq, :);

            % Waypoint Check Loop
            for k_point = 1:size(bpath_segment_eval, 1)
                checkp = bpath_segment_eval(k_point, :);
                x_cp = checkp(1, 1); y_cp = checkp(1, 2); z_cp = checkp(1, 3);
                z_interp_terrain = interp2(X, Y, Z, x_cp, y_cp, 'linear', -Inf);

                violation_occured_at_checkp = false;

                % Constraint: Height Upper Bound
                if z_cp > 0.2
                    flag_particle_segment(a) = 4;
                    current_hard_penalty = current_hard_penalty + 100;
                    violation_occured_at_checkp = true;
                end

                % Constraint: Terrain Collision
                if z_interp_terrain == -Inf % Out of map bounds
                    flag_particle_segment(a) = 5;
                    current_hard_penalty = current_hard_penalty + 10000;
                    violation_occured_at_checkp = true;
                elseif z_interp_terrain * 1.1 > z_cp % Too close to terrain
                    flag_particle_segment(a) = 3;
                    current_hard_penalty = current_hard_penalty + 1000;
                    violation_occured_at_checkp = true;
                end

                % Constraint: Dynamic Fire Zone
                bflag_fire = SFire(checkp, tget_segment_end, V_Fire, ellipse_params);
                if bflag_fire == 2 % Inside Fire Core
                    flag_particle_segment(a) = 2;
                    current_hard_penalty = current_hard_penalty + 100;
                    violation_occured_at_checkp = true;
                elseif bflag_fire == 1 % Inside Warning Zone
                    if z_cp < z_interp_terrain + 0.02 % Flying too low in warning zone
                        flag_particle_segment(a) = 2;
                        current_hard_penalty = current_hard_penalty + 100;
                        violation_occured_at_checkp = true;
                    end
                end

                %% Q-Learning Assisted Refinement ("Gene Feedback" Mechanism)
                % If a violation occurs and global solution is not yet perfect (goodmark=0)
                if violation_occured_at_checkp && goodmark == 0
                    fire_info.X = X; fire_info.Y = Y; fire_info.Z = Z;
                    fire_info.ellipse_params = ellipse_params;
                    
                    % Agent Action
                    [corrected_point_q, reward_from_q_agent, q_agent] = q_agent.correct_path(checkp, fire_info);
                    
                    if reward_from_q_agent > 0
                        % Calculate Correction Vector
                        correction_vector = corrected_point_q - checkp;
                        
                        % Map correction back to PSO genes (Control Points)
                        start_gene_idx_for_segment_a = (a-1) * 3 * points_per_segment_genes + 1;
                        end_gene_idx_for_segment_a   = a * 3 * points_per_segment_genes;
                        
                        current_segment_genes_flat = particles_updated(n, start_gene_idx_for_segment_a : end_gene_idx_for_segment_a);
                        reshaped_segment_genes = reshape(current_segment_genes_flat, 3, points_per_segment_genes)';
                        
                        % Distribute correction evenly across segment control points
                        for cp_idx = 1:points_per_segment_genes
                            reshaped_segment_genes(cp_idx, :) = reshaped_segment_genes(cp_idx, :) + ...
                                (correction_vector / points_per_segment_genes) * q_learning_rate_for_control_points;
                        end
                        
                        % Clamp modified genes to bounds
                        pmax_segment_bounds_flat = pmax_passed(start_gene_idx_for_segment_a : end_gene_idx_for_segment_a);
                        pmin_segment_bounds_flat = pmin_passed(start_gene_idx_for_segment_a : end_gene_idx_for_segment_a);
                        pmax_segment_bounds_matrix = reshape(pmax_segment_bounds_flat, 3, points_per_segment_genes)';
                        pmin_segment_bounds_matrix = reshape(pmin_segment_bounds_flat, 3, points_per_segment_genes)';
                        
                        reshaped_segment_genes = max(min(reshaped_segment_genes, pmax_segment_bounds_matrix), pmin_segment_bounds_matrix);
                        
                        % Update the particle in the population
                        modified_segment_genes_flat = reshape(reshaped_segment_genes', 1, []);
                        particles_updated(n, start_gene_idx_for_segment_a : end_gene_idx_for_segment_a) = modified_segment_genes_flat;
                    end
                end
            end
        end

        raw_cost_hard(n) = current_hard_penalty;
        pflag(n, :) = flag_particle_segment;

    end % End Particle Loop

    %% Adaptive Weighting Strategy
    % Dynamically adjust weights so secondary objectives (Height, Turn) match the scale of Path Length

    % 1. Calculate population means
    avg_len = mean(raw_cost_length);
    avg_h   = mean(raw_cost_height);
    avg_t   = mean(raw_cost_turn);

    % 2. Calculate Scaling Factors
    eps_val = 1e-6; % Prevent division by zero

    if avg_h > eps_val
        w_height = avg_len / avg_h;
    else
        w_height = 0;
    end

    if avg_t > eps_val
        w_turn = avg_len / avg_t;
    else
        w_turn = 0;
    end

    % 3. Calculate Final Fitness
    % Fitness = Length + (w_h * Height) + (w_t * Turn) + Hard_Penalty
    fitness = raw_cost_length + (w_height .* raw_cost_height) + (w_turn .* raw_cost_turn) + raw_cost_hard;

    %% Extract Global Best for Output
    [~, bestnum] = min(fitness);
    bestflag = pflag(bestnum, :);

    % Regenerate the full trajectory of the best particle
    best_anchors_flat = particles_z_for_pathgen(bestnum, :);
    best_anchors_mat  = reshape(best_anchors_flat, 3, [])';

    bx_anchors = best_anchors_mat(:, 1);
    by_anchors = best_anchors_mat(:, 2);
    bz_anchors = best_anchors_mat(:, 3);

    bi_seq_anchors = linspace(0, 1, length(bx_anchors));
    bI_seq_path = linspace(0, 1, 100);

    pbestX_seq = spline(bi_seq_anchors, bx_anchors, bI_seq_path);
    pbestY_seq = spline(bi_seq_anchors, by_anchors, bI_seq_path);
    pbestZ_seq = spline(bi_seq_anchors, bz_anchors, bI_seq_path);

end