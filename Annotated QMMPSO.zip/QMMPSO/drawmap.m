function [X, Y, Z] = drawmap(startPos, goalPos)  
    % Load Data
    % Ensure 'dataMatrix2.mat' is in the MATLAB path
    load('dataMatrix2.mat'); 
     
    % Extract x, y, z coordinates
    x = dataMatrix2(:, 1);  
    y = dataMatrix2(:, 2);  
    z = dataMatrix2(:, 3);  
    
    % Set data limits
    xmax = max(x); xmin = min(x);
    ymax = max(y); ymin = min(y);
    
    % Create Meshgrid
    [X, Y] = meshgrid(xmin:0.1:xmax, ymin:0.1:ymax); 

    % Cubic Interpolation for smooth terrain surface
    Z = griddata(x, y, z, X, Y, 'cubic');   
   
    %% Visualization
    figure(1); 
    hold on;
    
    % Plot Goal Points (Yellow)
    for i = 1:size(goalPos, 1)
        gx = goalPos(i, 1);
        gy = goalPos(i, 2);
        gz = goalPos(i, 3);
        scatter3(gx, gy, gz, 50, "yellow", 'filled');
    end
    
    % Plot Start Point (Red)
    sx = startPos(1);
    sy = startPos(2);
    sz = startPos(3);
    scatter3(sx, sy, sz, 50, "red", 'filled');
    
    % Plot Terrain Surface
    meshc(X, Y, Z);  
    shading flat;  
    
    % Figure Settings
    title('Interpolated Terrain Surface');  
    xlabel('X (km)');  
    ylabel('Y (km)');  
    zlabel('Z (km)');  
    ylim([0, 9]);
    zlim([0, 0.3]);
    
    hold on;
end