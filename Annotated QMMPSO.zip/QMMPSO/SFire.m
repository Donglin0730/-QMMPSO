function flag = SFire(point, time, V_Fire, ellipse_params)
    % flag: 0 = Safe, 1 = Warning Zone, 2 = Core Fire Zone
    flag = 0;
    x = point(1);
    y = point(2);
     
    for i = 1:size(ellipse_params, 1)
        center_x = ellipse_params(i, 1);
        center_y = ellipse_params(i, 2);
        a = ellipse_params(i, 4);
        b = ellipse_params(i, 5);
        
        % Calculate time-dependent ellipse semi-axes
        a = a + time/60 * V_Fire;
        b = b + time/60 * V_Fire;
        
        % Calculate expansion for Warning Zone (predicted state after 10 mins)
        expansion_radius_km = V_Fire * (10 / 60); 
        expanded_a = a + expansion_radius_km;
        expanded_b = b + expansion_radius_km;
        
        % Check if point is inside the ellipses
        % Check Core Fire Zone first
        if ((x - center_x)^2) / (a^2) + ((y - center_y)^2) / (b^2) <= 1
            flag = 2;
            return;
        % Check Warning Zone
        elseif ((x - center_x)^2) / (expanded_a^2) + ((y - center_y)^2) / (expanded_b^2) <= 1
            flag = 1;
            return;
        end
    end
end