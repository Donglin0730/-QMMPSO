clc
clear
close all

%% Map Model Definition
startPos = [1, 1, 0.06];
 
% Mission objectives: [x, y, z, stay_time]
goalPos = [
    5.0, 1, 0.08, 2;    
    3.4, 5, 0.1, 1;
    9.5, 3.6, 0.08, 1;
    7, 3.4, 0.09, 1;        
    7.2, 0.6, 0.08, 3;
];

% Traction points (Guidance points for initialization)
Traction_points = [
    3.2, 1.1, 0.07;
    4.1, 3, 0.15;
    5.7, 3.3, 0.15;
    8.3, 3, 0.15;
    9, 2, 0.15;
];

% Draw the static environment map
[X, Y, Z] = drawmap(startPos, goalPos); 
hold on;

%% Fire Visualization
% Fire spread speed calculation (km/h) based on Three-Point Estimation Method
O = 0.3; % Optimistic
M = 1.5; % Most likely
P = 3;   % Pessimistic
V_Fire = (O + P + 4 * M) / 6;

% UAV speed (km/min or consistent unit with simulation)
V_Uav = 0.05; 

% Predefined fire ellipse parameters: [center_x, center_y, center_z, a, b, h]
ellipse_params = [
    2.5, 4, 0, 1.1, 0.7, 0.2; 
    6, 2, 0, 1.2, 0.8, 0.2;  
    8.5, 5, 0, 0.7, 1.2, 0.2
];

% Draw initial fire state
time = 0;
drawfire(time, V_Fire, ellipse_params);
hold on;

% Add figure labels and decorations
xlabel('X Axis (km)');
ylabel('Y Axis (km)');
zlabel('Z Axis (km)');
title('Map with Fire Elliptic Cylinders');

%% Algorithm Execution
iterations_per_run = 300;

% Execute the QMMPSO algorithm
[bestx_run, besty_run, bestz_run, gbest_run_control_points, gbest_fit_run] = ...
        QMMPSO(Traction_points, startPos, goalPos, ellipse_params, V_Fire, V_Uav, X, Y, Z, iterations_per_run);

hold on;

% Plot the optimal path
plot3(bestx_run, besty_run, bestz_run, '-b', 'LineWidth', 1.5);

xlabel('X');
ylabel('Y');
zlabel('Z');
grid on;
hold off;