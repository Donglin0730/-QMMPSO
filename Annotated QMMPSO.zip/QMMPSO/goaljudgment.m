function [nsaftime, ngoalPos] = goaljudgment(startPos, goalPos, V_Uav, V_Fire, ellipse_params)
    %% Calculate Safety Time Windows
    % Determine the maximum time available before each mission point is engulfed by fire
    t_max = 200; % Maximum simulation time (min)
    dt = 0.01;   % Time step
    saftime = zeros(1, 5);
    DSP = zeros(1, 5); % Distance from Start Point
    P1 = startPos(1, 1:3);
     
    for i = 1:size(goalPos, 1)
        P2 = goalPos(i, 1:3);
        time = 0; % min
        while time <= t_max            
            flag = SFire(P2, time, V_Fire, ellipse_params);
            if flag ~= 0
                % Point covered by warning zone, break loop
                break; 
            end
            % Increment time
            time = time + dt;
        end
        saftime(i) = time;
        DSP(i) = sqrt(sum((P2 - P1).^2));
    end

    %% Task Prioritization and Sorting
    % Calculate priority score based on Mission Duration, Safety Time, and Distance
    % Weights: 0.1 (Duration), 0.8 (Safety Time), 0.1 (Distance)
    % Lower score indicates higher urgency/priority.
    goaltime = goalPos(:, 4).';  % Get mission duration
    score = goaltime/sum(goaltime)*0.1 + saftime/sum(saftime)*0.8 + DSP/sum(DSP)*0.1; 
    
    % Sort tasks based on score in ascending order (Highest priority first)
    [~, sortIdx] = sort(score, 'ascend');
    
    % Reorder goal positions and safety times
    ngoalPos = zeros(size(goalPos));
    for i = 1:size(goalPos, 1)
        ngoalPos(i, :) = goalPos(sortIdx(i), :);
    end
    nsaftime = zeros(1, size(goalPos, 1));
    for i = 1:size(goalPos, 1)
        nsaftime(i) = saftime(sortIdx(i));
    end    

    %% Feasibility Validation
    % Check if the sorted sequence is executable by a single UAV
    temp = 0;
    tfly = zeros(1, 5);
    tget = zeros(1, 5);
    tfinish = zeros(1, 5);
    intersect = zeros(1, 3);
    
    % Reset P1 to start position for the sequence check
    P1 = startPos(1, 1:3); 

    for i = 1:size(ngoalPos, 1)
        P2 = ngoalPos(i, 1:3);
        
        % Check for fire intersections along the direct path
        for j = 1:size(ellipse_params, 1)
            center = ellipse_params(j, 1:2);
            % Estimate fire size at arrival time (Conservative estimation)
            time_est = (nsaftime(i) - ngoalPos(i, 4)) + 10; % buffer included
            expansion = V_Fire * time_est / 60 + V_Fire/6; 
            
            a = ellipse_params(j, 4) + expansion;
            b = ellipse_params(j, 5) + expansion;
            intersect(j) = lineEllipseIntersect(P1, P2, center, a, b);         
        end
        
        % Calculate distance with detours if intersection exists
        distance = sqrt(sum((P2 - P1).^2));
        for j = 1:size(ellipse_params, 1)
            if intersect(j)
                % Add detour distance approximation (half circumference of the ellipse)
                time_est = (nsaftime(i) - ngoalPos(i, 4)) + 10;
                expansion = V_Fire * time_est / 60 + V_Fire/6;
                a = ellipse_params(j, 4) + expansion;
                b = ellipse_params(j, 5) + expansion;
                % Ramanujan's approximation for ellipse perimeter / 2
                distance = distance + pi * (3 * (a + b) - sqrt((3*a + b) * (a + 3*b))) / 2;
            end
        end
        
        % Calculate flight time
        tfly(i) = distance / V_Uav / 60;  % Flight time in minutes
        tget(i) = temp + tfly(i);         % Arrival time
        
        % Check against safety time constraint
        if (tget(i) + ngoalPos(i, 4)) < nsaftime(i)
            tfinish(i) = tget(i) + ngoalPos(i, 4);
            temp = tfinish(i);
        else 
            fprintf("Feasibility Check Failed: Mission impossible for single UAV. Multi-UAV solution recommended.\n");
            break
        end
        P1 = P2; % Update current position for next segment
    end
    
    %% Nested Helper Function: Intersection Check
    function intersect = lineEllipseIntersect(P1, P2, center, a, b)
        % Check if the projection of the flight path intersects with the fire ellipse
        % P1, P2: Endpoints; center: Ellipse center; a, b: Semi-axes
    
        % Define coefficients of the quadratic equation
        A = (P2(1) - P1(1))^2 / a^2 + (P2(2) - P1(2))^2 / b^2;
        B = 2 * ((P2(1) - P1(1)) * (P1(1) - center(1)) / a^2 + ...
                 (P2(2) - P1(2)) * (P1(2) - center(2)) / b^2);
        C = (P1(1) - center(1))^2 / a^2 + (P1(2) - center(2))^2 / b^2 - 1;
    
        % Solve quadratic equation
        t = roots([A, B, C]);
    
        % Check for real solutions within segment [0, 1]
        intersect = any(imag(t) == 0 & t >= 0 & t <= 1);
    end
end