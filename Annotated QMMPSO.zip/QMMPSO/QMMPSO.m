function [bestx, besty, bestz, gbest, gbest_fit] = QMMPSO(Traction_points, startPos, goalPos, ellipse_params, V_Fire, V_Uav, X, Y, Z, num_iterations_total)
    
    %% Persistent Q-Learning Agent Initialization
    % Ensure the Q-Agent persists across multiple calls to QMMPSO
    persistent q_agent_global; 
    if isempty(q_agent_global)
        grid_resolution_for_q = 0.25; % Grid resolution for Q-learning state space
         
        learning_params_q.initial_alpha = 0.6;      % Initial learning rate
        learning_params_q.min_alpha = 0.01;
        learning_params_q.alpha_decay_rate = 0.9995; % Decay rate per update
        
        learning_params_q.initial_epsilon = 0.7;    % Initial exploration rate
        learning_params_q.min_epsilon = 0.05;
        learning_params_q.epsilon_decay_rate = 0.9995; 
    
        q_agent_global = QLearning_Agent(grid_resolution_for_q, learning_params_q);
    end

    %% Preprocessing: Mission Sequence Optimization
    % Sort goals based on temporal urgency and distance
    [nsaftime, ngoalPos] = goaljudgment(startPos, goalPos, V_Uav, V_Fire, ellipse_params);

    %% Parameter Initialization
    goodmark = 0;           % Flag indicating if a feasible solution has been found
    N = 100;                % Population size
    num = num_iterations_total; % Total iterations
    M = 15;                 % Total number of control points (3 points * 5 segments)
    remark = 0;             % Flag for historical best injection
    
    % PSO Inertia and Learning Factors
    w_max = 0.9; w_min = 0.3;   % Inertia weight range
    c1_max = 2.5; c1_min = 1.5; % Cognitive component range
    c2_max = 2.5; c2_min = 1.5; % Social component range

    Onesn1 = ones(N, 1);
    Ones1m = ones(1, 3*M);

    % Matrices Initialization
    particles = zeros(N, 3*M);   % Position matrix
    velocities = zeros(N, 3*M);  % Velocity matrix
    pmax = zeros(N, 3*M);        % Position upper bound
    pmin = zeros(N, 3*M);        % Position lower bound
    vmax = zeros(N, 3*M);        % Velocity upper bound
    vmin = zeros(N, 3*M);        % Velocity lower bound

    % Define Bounds for Velocity and Position
    for i = 1:N
        for j = 1:M
            % Velocity bounds
            vmax(i, (j-1)*3 + 1) = 0.3;  vmin(i, (j-1)*3 + 1) = -0.3;  % Vx
            vmax(i, (j-1)*3 + 2) = 0.3;  vmin(i, (j-1)*3 + 2) = -0.3;  % Vy
            vmax(i, (j-1)*3 + 3) = 0.01; vmin(i, (j-1)*3 + 3) = -0.01; % Vz (smaller vertical velocity)

            % Position bounds
            pmax(i, (j-1)*3 + 1) = 11;   pmin(i, (j-1)*3 + 1) = 0;     % X bound [0, 11]
            pmax(i, (j-1)*3 + 2) = 8;    pmin(i, (j-1)*3 + 2) = 0;     % Y bound [0, 8]
            pmax(i, (j-1)*3 + 3) = 0.2;  pmin(i, (j-1)*3 + 3) = 0.05;  % Z bound [0.05, 0.2]
        end
    end
    
    %% Population Initialization: Skeleton + Perturbation
    % Construct a basic path skeleton connecting start and goals, then add noise
    Pos = [startPos; ngoalPos(:, (1:3))];
    num_segments = size(goalPos, 1); 
    
    if M < num_segments || mod(M, num_segments) ~= 0
        error('M must be an integer multiple of the number of segments.');
    end
    intermediate_points_per_segment = M / num_segments; 

    for i = 1:N
        current_idx_in_chromosome = 1;
        for seg = 1:num_segments
            p1 = Pos(seg, :);   
            p2 = Pos(seg+1, :); 

            % Linear interpolation for intermediate points
            if intermediate_points_per_segment > 0
                t = linspace(0, 1, intermediate_points_per_segment + 2)'; 
                t = t(2:end-1); % Exclude start and end points of the segment

                intermediate_xyz = zeros(intermediate_points_per_segment, 3);
                for dim = 1:3 
                    intermediate_xyz(:, dim) = p1(dim) + t * (p2(dim) - p1(dim));
                end

                % Add random perturbation
                perturb_range_x = 0.5 * (pmax(1) - pmin(1)); 
                perturb_range_z = 0.5 * (pmax(3) - pmin(3)); 

                perturbation = (rand(intermediate_points_per_segment, 3) - 0.5);
                perturbation(:, 1:2) = perturbation(:, 1:2) * perturb_range_x * 0.1; % XY perturbation
                perturbation(:, 3)   = perturbation(:, 3)   * perturb_range_z * 0.1; % Z perturbation

                intermediate_xyz_perturbed = intermediate_xyz + perturbation;

                % Flatten and store in particle
                flat_points = reshape(intermediate_xyz_perturbed', 1, []);
                end_idx_in_chromosome = current_idx_in_chromosome + length(flat_points) - 1;
                particles(i, current_idx_in_chromosome:end_idx_in_chromosome) = flat_points;
                current_idx_in_chromosome = end_idx_in_chromosome + 1;
            end
        end
    end

    % Initialize Random Velocities
    for i = 1:N
        for j = 1:M
            velocities(i, (j-1)*3 + 1) = -0.3 + (rand * 0.6);   % Vx
            velocities(i, (j-1)*3 + 2) = -0.3 + (rand * 0.6);   % Vy
            velocities(i, (j-1)*3 + 3) = -0.01 + (rand * 0.02); % Vz
        end
    end
    particles = particles + velocities;

    %% Initialization Strategy 2: Prior Knowledge Guidance (Traction)
    % Pull control points towards safe "Traction Points" (guidance points)
    num_goals = size(goalPos, 1);
    segment_size = 3 * intermediate_points_per_segment; 
    points_per_segment = M / num_goals;

    for row_idx = 1:N
        current_row = particles(row_idx, :);
        for j = 1:num_goals 
            start_idx = (j-1)*segment_size + 1;
            end_idx = j*segment_size;
            
            group_points = reshape(current_row(start_idx:end_idx), 3, points_per_segment)';
            target_point = Traction_points(j, :); 
            
            mean_point = mean(group_points, 1);
            adjustment = 0.5 * (target_point - mean_point); % Pull factor
            
            adjusted_points = group_points + adjustment; 
            adjusted_group = reshape(adjusted_points', 1, []); 
            particles(row_idx, start_idx:end_idx) = adjusted_group;
        end
    end
    
    %% Initialization Strategy 3: Fire Escape Mechanism
    % If initialized points fall into fire zones, move them away along the gradient
    step_size = 0.5;   
    num_particles = size(particles, 1);  
    num_fires = size(ellipse_params, 1);     
    
    for i = 1:num_particles                  
        for j = 1:15                         
            col_x = 3*(j-1) + 1;             
            col_y = 3*(j-1) + 2;             
            col_z = 3*(j-1) + 3;             
            
            x = particles(i, col_x);
            y = particles(i, col_y);
            
            nearest_fire = -1;               
            min_distance = Inf;              
            
            % Find nearest fire threat
            for k = 1:num_fires
                cx = ellipse_params(k, 1);   
                cy = ellipse_params(k, 2);   
                ea = ellipse_params(k, 4);    
                eb = ellipse_params(k, 5);    
                
                x_trans = x - cx;
                y_trans = y - cy;
                
                % Check if inside ellipse (ignoring Z for vertical cylinder model)
                if (x_trans / ea)^2 + (y_trans / eb)^2 <= 1
                    distance = sqrt(x_trans^2 + y_trans^2);
                    if distance < min_distance
                        min_distance = distance;
                        nearest_fire = k;
                    end
                end
            end
            
            % Execute Escape
            if nearest_fire ~= -1
                cx = ellipse_params(nearest_fire, 1);
                cy = ellipse_params(nearest_fire, 2);
                ea = ellipse_params(nearest_fire, 4);
                eb = ellipse_params(nearest_fire, 5);
                
                % Calculate gradient direction
                x_trans = x - cx;
                y_trans = y - cy;
                grad_x = 2 * x_trans / ea^2;
                grad_y = 2 * y_trans / eb^2;
                
                % Normalize and move
                mag_grad = norm([grad_x, grad_y]);
                if mag_grad > 0
                    escape_dir = [grad_x, grad_y] / mag_grad;
                    particles(i, col_x) = x + escape_dir(1) * step_size;
                    particles(i, col_y) = y + escape_dir(2) * step_size;
                end
            end
        end
    end
    
    %% Initial Evaluation
    k_neighbors = 5;  
    lbest = zeros(size(particles));  
    
    % Evaluate fitness (with Q-Learning refinement)
    [fitness, bestflag, pflag, bestnum, pbestX_seq, pbestY_seq, pbestZ_seq, particles_updated_by_calfitness] = ...
            calfitness(1, pmax(1,:), pmin(1,:), startPos, goalPos, ellipse_params, M, N, particles, ngoalPos, X, Y, Z, V_Uav, V_Fire, nsaftime, goodmark, q_agent_global);
    
    particles = particles_updated_by_calfitness;
    
    % Initialize Personal and Global Bests
    gbest = particles(bestnum, :);
    gbest_fit = 1000000000; % Initialize with a large value
    pbest = particles;
    pbest_fit = 1000000000 * ones(N, 1);
    
    bestx = pbestX_seq;
    besty = pbestY_seq;
    bestz = pbestZ_seq;

    % Historical Best Records
    lsmask = zeros(1, 5);
    lsbest = zeros(1, 45);

    %% Main Optimization Loop
    for a = 1:num
        % Linear decay of parameters
        w = w_max - (w_max - w_min) * (a / num);
        c1 = c1_max - (c1_max - c1_min) * (a / num);
        c2 = c2_min + (c2_max - c2_min) * (a / num);
        R1 = rand(N, 3*M);
        R2 = rand(N, 3*M);

        %% Multi-Strategy: Dynamic Topology Switching
        if a < 30 % Phase 1: KNN Local Topology (Enhance Diversity)
            % Calculate distance between particles based on control points
            control_points = particles(:, 1:3:end); 
            dist_matrix = squareform(pdist(control_points)); 
            
            % Find k-nearest neighbors
            for i = 1:N
                [~, sorted_idx] = sort(dist_matrix(i, :));
                neighbors = sorted_idx(1:k_neighbors);
                
                % Find local best in neighborhood
                [~, best_idx] = min(pbest_fit(neighbors));
                lbest(i, :) = pbest(neighbors(best_idx), :);
            end
            % Update velocity using Local Best (lbest)
            velocities = w * velocities + c1 * R1 .* (pbest - particles) + c2 * R2 .* (lbest - particles);
        else % Phase 2: Global Topology (Accelerate Convergence)
            % Update velocity using Global Best (gbest)
            velocities = w * velocities + c1 * R1 .* (pbest - particles) + c2 * R2 .* (Onesn1 * gbest - particles);
        end

        % Clamp Velocities
        indices = velocities > vmax; velocities(indices) = vmax(indices);
        indices = velocities < vmin; velocities(indices) = vmin(indices);

        % Update Positions
        particles = particles + velocities;

        % Clamp Positions
        indices = particles > pmax; particles(indices) = pmax(indices);
        indices = particles < pmin; particles(indices) = pmin(indices);
        
        %% Multi-Strategy: Periodic Segment Crossover
        if mod(a, 10) == 0
            Pc = 0.8; % Crossover probability
            num_segments_cross = num_goals; 
            segment_len = 3 * points_per_segment; 
    
            shuffled_indices = randperm(N);
            for i = 1:2:N-1 
                p1_idx = shuffled_indices(i);
                p2_idx = shuffled_indices(i+1);
    
                if rand < Pc
                    for k = 1:num_segments_cross
                        % Swap segment with 50% probability
                        if rand < 0.5
                            start_col = (k-1) * segment_len + 1;
                            end_col = k * segment_len;
    
                            temp_segment = particles(p1_idx, start_col:end_col);
                            particles(p1_idx, start_col:end_col) = particles(p2_idx, start_col:end_col);
                            particles(p2_idx, start_col:end_col) = temp_segment;
                        end
                    end
                end
            end
        end

        %% Multi-Strategy: Historical Best Injection
        % If a complete feasible solution was composed from history but not found by current swarm
        if remark == 1
            particles = Onesn1 * lsbest; % Inject constructed solution into population
            remark = 2; % Ensure injection happens only once
        end

        % Evaluate Fitness
        [fitness, bestflag, pflag, bestnum, pbestX_seq, pbestY_seq, pbestZ_seq, particles_updated_by_calfitness] = ...
                calfitness(1, pmax(1,:), pmin(1,:), startPos, goalPos, ellipse_params, M, N, particles, ngoalPos, X, Y, Z, V_Uav, V_Fire, nsaftime, goodmark, q_agent_global);
    
        particles = particles_updated_by_calfitness; % Update particles (Q-learning might have modified them)
        
        % Update Personal Best
        logic = fitness < pbest_fit;
        pbest = logic * Ones1m .* particles + (1-logic) * Ones1m .* pbest;
        pbest_fit = logic .* fitness + (1-logic) .* pbest_fit;

        % Update Global Best
        if pbest_fit(bestnum) < gbest_fit
            gbest = particles(bestnum, :);
            gbest_fit = pbest_fit(bestnum);
            bestx = pbestX_seq;
            besty = pbestY_seq;
            bestz = pbestZ_seq;
        end

        %% Record Historical Best Segments
        % If valid global solution not found yet (remark == 0), try to assemble one
        if remark == 0
            if all(lsmask(:) == 1) 
                remark = 1; % All segments found, ready to inject
            else 
                for h = 1:5 % For each mission segment
                    for n = 1:N
                        % If segment h is valid (pflag==0) and not yet recorded
                        if pflag(n, h) == 0 && lsmask(h) == 0
                            temppar = particles(n, :);
                            % Store the valid segment genes
                            lsbest(((h-1)*9 + 1):h*9) = temppar(((h-1)*9 + 1):h*9);
                            lsmask(h) = 1;
                        end
                    end
                end
            end
        end
        
        % Check if a "Good Enough" solution is found to disable Q-learning overhead later
        if gbest_fit < 100
            goodmark = 1;
        end

        % Console Output
        fprintf("Iteration %d | Mean Fit: %.4f | Current Best: %.4f | Global Best: %.4f\n", ...
                a, mean(fitness), fitness(bestnum), gbest_fit);
 
    end
end